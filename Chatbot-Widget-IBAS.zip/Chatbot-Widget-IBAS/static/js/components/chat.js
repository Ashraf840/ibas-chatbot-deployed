`{% load static %}`


/**
 * scroll to the bottom of the chats after new message has been added to chat
 */
const converter = new showdown.Converter();
function scrollToBottomOfResults() {
    const terminalResultsDiv = document.getElementById("chats");
    terminalResultsDiv.scrollTop = terminalResultsDiv.scrollHeight;
}




/**
 * Set user response on the chat screen
 * @param {String} message user message
 */
function setUserResponse(message) {
    const user_response = `<img class="userAvatar" src='https://media.istockphoto.com/id/1300845620/vector/user-icon-flat-isolated-on-white-background-user-symbol-vector-illustration.jpg?s=612x612&w=0&k=20&c=yBeyba0hUkh14_jgv1OKqIH0CCSWU_4ckRkAoy2p73o='><p class="userMsg">${message} </p><div class="clearfix"></div>`;
    $(user_response).appendTo(".chats").show("slow");

    $(".usrInput").val("");
    scrollToBottomOfResults();
    showBotTyping();
    $(".suggestions").remove();
}


/**
 * returns formatted bot response 
 * @param {String} text bot message response's text
 *
 */
function getBotResponse(text) {
    botResponse = `<img class="botAvatar" src="https://st3.depositphotos.com/30456762/37578/v/600/depositphotos_375780486-stock-illustration-chat-bot-robot-avatar-in.jpg"/><span class="botMsg">${text}</span><div class="clearfix"></div>`;
    return botResponse;
}

/**
 * renders bot response on to the chat screen
 * @param {Array} response json array containing different types of bot response
 *
 */
async function identifyMessage(message) {
    try {
      const response = await fetch(ADPI_url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message: message }),
      });
  
      if (!response.ok) {
        throw new Error('Request failed');
      }
  
      const data = await response.json();
      return data.matches;
    } catch (error) {
      console.error('Error:', error.message);
      // Handle the error appropriately
    }
  }

function setBotResponse(response) {
    // renders bot response after 500 milliseconds
    setTimeout(() => {
        hideBotTyping(); 
        if (response_status=="success" && response.length < 1 ){
            const fallbackMsg = "দুঃখিত কোনো ধরনের সমস্যা হয়েছে, পুনরায় চেষ্টা করুন";
            const BotResponse = `<img class="botAvatar" src="https://st3.depositphotos.com/30456762/37578/v/600/depositphotos_375780486-stock-illustration-chat-bot-robot-avatar-in.jpg"/><p class="botMsg">${fallbackMsg}</p><div class="clearfix"></div>`;

            $(BotResponse).appendTo(".chats").hide().fadeIn(1000);
            scrollToBottomOfResults();
        }
        else if(response_status=="success"){
            // if we get response from Rasa
            for (let i = 0; i < response.length; i += 1) {
                // check if the response contains "text"
                if (Object.hasOwnProperty.call(response[i], "text")) {
                    if (response[i].text != null) {
                        // convert the text to mardown format using showdown.js(https://github.com/showdownjs/showdown);
                        let botResponse;
                        let html = converter.makeHtml(response[i].text);
                        html = html.replaceAll("<p>", "").replaceAll("</p>", "").replaceAll("<strong>", "<b>").replaceAll("</strong>", "</b>");
                        html = html.replace(/(?:\r\n|\r|\n)/g, '<br>')
                        console.log(html);
                        // check for blockquotes
                        if (html.includes("<blockquote>")) {
                            html = html.replaceAll("<br>", "");
                            botResponse = getBotResponse(html);
                        }
                        // check for image
                        if (html.includes("<img")) {
                            html = html.replaceAll("<img", '<img class="imgcard_mrkdwn" ');
                            botResponse = getBotResponse(html);
                        }
                        // check for preformatted text
                        if (html.includes("<pre") || html.includes("<code>")) {

                            botResponse = getBotResponse(html);
                        }
                        // check for list text
                        if (html.includes("<ul") || html.includes("<ol") || html.includes("<li") || html.includes('<h3')) {
                            html = html.replaceAll("<br>", "");
                            botResponse = getBotResponse(html);
                        }
                        else {
                            // if no markdown formatting found, render the text as it is.
                            if (!botResponse) {
                                botResponse = `<img class="botAvatar" src="https://st3.depositphotos.com/30456762/37578/v/600/depositphotos_375780486-stock-illustration-chat-bot-robot-avatar-in.jpg"/><p class="botMsg">${response[i].text}</p><div class="clearfix"></div>`;
                            }
                        }
                        // append the bot response on to the chat screen
                        $(botResponse).appendTo(".chats").hide().fadeIn(1000);
                        console.log("Identify Message: ",identifyMessage(response[i].text))
                        if (identifyMessage(response[i].text)==1){
                            addHumanFeedback();
                        }
                    }
                }

                // check if the response contains "images"
                if (Object.hasOwnProperty.call(response[i], "image")) {
                    if (response[i].image !== null) {
                        const BotResponse = `<div class="singleCard"><img class="imgcard" src="${response[i].image}"></div><div class="clearfix">`;

                        $(BotResponse).appendTo(".chats").hide().fadeIn(1000);
                    }
                }

                // check if the response contains "buttons"
                if (Object.hasOwnProperty.call(response[i], "buttons")) {
                    if (response[i].buttons.length > 0) {
                        addSuggestion(response[i].buttons);
                    }
                }

                // check if the response contains "attachment"
                if (Object.hasOwnProperty.call(response[i], "attachment")) {
                    if (response[i].attachment != null) {
                        if (response[i].attachment.type === "video") {
                            // check if the attachment type is "video"
                            const video_url = response[i].attachment.payload.src;

                            const BotResponse = `<div class="video-container"> <iframe src="${video_url}" frameborder="0" allowfullscreen></iframe> </div>`;
                            $(BotResponse).appendTo(".chats").hide().fadeIn(1000);
                        }
                    }
                }
                // check if the response contains "custom" message
                if (Object.hasOwnProperty.call(response[i], "custom")) {
                    const { payload } = response[i].custom;
                    if (payload === "quickReplies") {
                        // check if the custom payload type is "quickReplies"
                        const quickRepliesData = response[i].custom.data;
                        showQuickReplies(quickRepliesData);
                        return;
                    }

                    // check if the custom payload type is "pdf_attachment"
                    if (payload === "pdf_attachment") {
                        renderPdfAttachment(response[i]);
                        return;
                    }

                    // check if the custom payload type is "dropDown"
                    if (payload === "dropDown") {
                        const dropDownData = response[i].custom.data;
                        renderDropDwon(dropDownData);
                        return;
                    }

                    // check if the custom payload type is "location"
                    if (payload === "location") {
                        $("#userInput").prop("disabled", true);
                        getLocation();
                        scrollToBottomOfResults();
                        return;
                    }

                    // check if the custom payload type is "cardsCarousel"
                    if (payload === "cardsCarousel") {
                        const restaurantsData = response[i].custom.data;
                        showCardsCarousel(restaurantsData);
                        return;
                    }

                    // check if the custom payload type is "chart"
                    if (payload === "chart") {
                        const chartData = response[i].custom.data;
                        const {
                            title,
                            labels,
                            backgroundColor,
                            chartsData,
                            chartType,
                            displayLegend,
                        } = chartData;

                        createChart(
                            title,
                            labels,
                            backgroundColor,
                            chartsData,
                            chartType,
                            displayLegend,
                        );

                        $(document).on("click", "#expand", () => {
                            createChartinModal(
                                title,
                                labels,
                                backgroundColor,
                                chartsData,
                                chartType,
                                displayLegend,
                            );
                        });
                        return;
                    }

                    // check of the custom payload type is "collapsible"
                    if (payload === "collapsible") {
                        const { data } = response[i].custom;
                        createCollapsible(data);
                    }
                }
            }
            scrollToBottomOfResults();
        }
        else {
            // if there is no response from Rasa, send  fallback message to the user
            const fallbackMsg = "দুঃখিত কোনো ধরনের সমস্যা হয়েছে, পুনরায় চেষ্টা করুন";
            const BotResponse = `<img class="botAvatar" src="https://st3.depositphotos.com/30456762/37578/v/600/depositphotos_375780486-stock-illustration-chat-bot-robot-avatar-in.jpg"/><p class="botMsg">${fallbackMsg}</p><div class="clearfix"></div>`;
            console.log(response_status)
            $(BotResponse).appendTo(".chats").hide().fadeIn(1000);
            scrollToBottomOfResults();
        }
        $(".usrInput").focus();
    }, 500);

}


function sendBotResponseToCH(response) {
    // renders bot response after 500 milliseconds
    setTimeout(() => {
        hideBotTyping(); 
        if (response_status=="success" && response.length < 1 ){
            const fallbackMsg = "দুঃখিত কোনো ধরনের সমস্যা হয়েছে, পুনরায় চেষ্টা করুন";
            const BotResponse = `<img class="botAvatar" src="https://st3.depositphotos.com/30456762/37578/v/600/depositphotos_375780486-stock-illustration-chat-bot-robot-avatar-in.jpg"/><p class="botMsg">${fallbackMsg}</p><div class="clearfix"></div>`;

            // $(BotResponse).appendTo(".chats").hide().fadeIn(1000);
            scrollToBottomOfResults();
        }
        else if(response_status=="success"){
            // if we get response from Rasa
            for (let i = 0; i < response.length; i += 1) {
                // check if the response contains "text"
                if (Object.hasOwnProperty.call(response[i], "text")) {
                    if (response[i].text != null) {
                        // convert the text to mardown format using showdown.js(https://github.com/showdownjs/showdown);
                        let botResponse;
                        let html = converter.makeHtml(response[i].text);
                        html = html.replaceAll("<p>", "").replaceAll("</p>", "").replaceAll("<strong>", "<b>").replaceAll("</strong>", "</b>");
                        html = html.replace(/(?:\r\n|\r|\n)/g, '<br>')
                        console.log("Clickhouse response: ", html)
                        return html;
                        // check for blockquotes
                        if (html.includes("<blockquote>")) {
                            html = html.replaceAll("<br>", "");
                            botResponse = getBotResponse(html);
                        }
                        // check for image
                        if (html.includes("<img")) {
                            html = html.replaceAll("<img", '<img class="imgcard_mrkdwn" ');
                            botResponse = getBotResponse(html);
                        }
                        // check for preformatted text
                        if (html.includes("<pre") || html.includes("<code>")) {

                            botResponse = getBotResponse(html);
                        }
                        // check for list text
                        if (html.includes("<ul") || html.includes("<ol") || html.includes("<li") || html.includes('<h3')) {
                            html = html.replaceAll("<br>", "");
                            botResponse = getBotResponse(html);
                        }
                        else {
                            // if no markdown formatting found, render the text as it is.
                            if (!botResponse) {
                                botResponse = `<img class="botAvatar" src="https://st3.depositphotos.com/30456762/37578/v/600/depositphotos_375780486-stock-illustration-chat-bot-robot-avatar-in.jpg"/><p class="botMsg">${response[i].text}</p><div class="clearfix"></div>`;
                            }
                        }
                        // append the bot response on to the chat screen
                        $(botResponse).appendTo(".chats").hide().fadeIn(1000);
                        console.log("Identify Message: ",identifyMessage(response[i].text))
                        if (identifyMessage(response[i].text)==1){
                            addHumanFeedback();
                        }
                    }
                }

                // check if the response contains "images"
                if (Object.hasOwnProperty.call(response[i], "image")) {
                    if (response[i].image !== null) {
                        const BotResponse = `<div class="singleCard"><img class="imgcard" src="${response[i].image}"></div><div class="clearfix">`;

                        $(BotResponse).appendTo(".chats").hide().fadeIn(1000);
                    }
                }

                // check if the response contains "buttons"
                if (Object.hasOwnProperty.call(response[i], "buttons")) {
                    if (response[i].buttons.length > 0) {
                        addSuggestion(response[i].buttons);
                    }
                }

                // check if the response contains "attachment"
                if (Object.hasOwnProperty.call(response[i], "attachment")) {
                    if (response[i].attachment != null) {
                        if (response[i].attachment.type === "video") {
                            // check if the attachment type is "video"
                            const video_url = response[i].attachment.payload.src;

                            const BotResponse = `<div class="video-container"> <iframe src="${video_url}" frameborder="0" allowfullscreen></iframe> </div>`;
                            $(BotResponse).appendTo(".chats").hide().fadeIn(1000);
                        }
                    }
                }
                // check if the response contains "custom" message
                if (Object.hasOwnProperty.call(response[i], "custom")) {
                    const { payload } = response[i].custom;
                    if (payload === "quickReplies") {
                        // check if the custom payload type is "quickReplies"
                        const quickRepliesData = response[i].custom.data;
                        showQuickReplies(quickRepliesData);
                        return;
                    }

                    // check if the custom payload type is "pdf_attachment"
                    if (payload === "pdf_attachment") {
                        renderPdfAttachment(response[i]);
                        return;
                    }

                    // check if the custom payload type is "dropDown"
                    if (payload === "dropDown") {
                        const dropDownData = response[i].custom.data;
                        renderDropDwon(dropDownData);
                        return;
                    }

                    // check if the custom payload type is "location"
                    if (payload === "location") {
                        $("#userInput").prop("disabled", true);
                        getLocation();
                        scrollToBottomOfResults();
                        return;
                    }

                    // check if the custom payload type is "cardsCarousel"
                    if (payload === "cardsCarousel") {
                        const restaurantsData = response[i].custom.data;
                        showCardsCarousel(restaurantsData);
                        return;
                    }

                    // check if the custom payload type is "chart"
                    if (payload === "chart") {
                        const chartData = response[i].custom.data;
                        const {
                            title,
                            labels,
                            backgroundColor,
                            chartsData,
                            chartType,
                            displayLegend,
                        } = chartData;

                        createChart(
                            title,
                            labels,
                            backgroundColor,
                            chartsData,
                            chartType,
                            displayLegend,
                        );

                        $(document).on("click", "#expand", () => {
                            createChartinModal(
                                title,
                                labels,
                                backgroundColor,
                                chartsData,
                                chartType,
                                displayLegend,
                            );
                        });
                        return;
                    }

                    // check of the custom payload type is "collapsible"
                    if (payload === "collapsible") {
                        const { data } = response[i].custom;
                        createCollapsible(data);
                    }
                }
            }
            scrollToBottomOfResults();
        }
        else {
            // if there is no response from Rasa, send  fallback message to the user
            const fallbackMsg = "দুঃখিত কোনো ধরনের সমস্যা হয়েছে, পুনরায় চেষ্টা করুন";
            const BotResponse = `<img class="botAvatar" src="https://st3.depositphotos.com/30456762/37578/v/600/depositphotos_375780486-stock-illustration-chat-bot-robot-avatar-in.jpg"/><p class="botMsg">${fallbackMsg}</p><div class="clearfix"></div>`;
            console.log(response_status)
            $(BotResponse).appendTo(".chats").hide().fadeIn(1000);
            scrollToBottomOfResults();
        }
        $(".usrInput").focus();
    }, 500);

}

function addHumanFeedback(){
    
    const text = "Was it helpful?"

    const HumanFeedbaclQuery = `<p class="botMsg">${text}</p><div class="clearfix"></div>`;
    const yesButton = `<button class="feedbackButton" onclick="getHumanFeedback('yes')">Yes</button>`;
    const noButton = `<button class="feedbackButton" onclick="getHumanFeedback('no')">No</button><div class="clearfix"></div>`;

    $(HumanFeedbaclQuery).appendTo(".chats").hide().fadeIn(1000);
    $(yesButton).appendTo(".chats").hide().fadeIn(1000);
    $(noButton).appendTo(".chats").hide().fadeIn(1000);
}

function getHumanFeedback(text){
    humanFeedback = text;
    sendAllValues();
    if (text == 'yes'){
        console.log("feedback text: ", text)
    }
    else {
        console.log("feedback text: ", text)

    }
}

function sendDataToClickHouse(message, botResp){
    let response;
    console.log("userText: ",message)
    console.log("botResp: ", botResp)

    $.ajax({
        url: rasa_server_url,
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify({ message, sender: sender_id }),
        success(botResponse, status) {
            console.log("Response from Rasa: ", botResponse, "\nStatus: ", status);
            console.log("Response from Rasa botResponse.text: ", botResponse[0].text)
            response_status = status
            console.log("response_status", response_status);
            response =  sendBotResponseToCH(botResponse.messages);
            console.log("botResponse in the : ", response)

            if (message.toLowerCase() === "/restart") {
                $("#userInput").prop("disabled", false);

                return;
            }
            response =  sendBotResponseToCH(botResponse);
            console.log("botResponse in the ClickHouse thing: ", response)
        },
        error(xhr, textStatus) {
            if (userText.toLowerCase() === "/restart") {
                $("#userInput").prop("disabled", false);

            }

            setBotResponse("");
            console.log("Error from bot end: ", textStatus);
        },
    });

    console.log("botResponse in the ClickHouse thing: ", response)

    // const hf = randomFrom(['yes', 'no', 'no comments']);
    const hf = 'yes';

    console.log("Human Feedback: ", hf);

}

function setNIDverificationSuccessful(){
    hideBotTyping();
    const is_verified_message = "NID Verified succesfully";
    const BotResponse = `<img class="botAvatar" src="https://st3.depositphotos.com/30456762/37578/v/600/depositphotos_375780486-stock-illustration-chat-bot-robot-avatar-in.jpg"/><p class="botMsg">${is_verified_message}</p><div class="clearfix"></div>`;

    $(BotResponse).appendTo(".chats").hide().fadeIn(2000); 
}

function speechNotRecognized(){
    hideBotTyping();
    const is_verified_message = "Speech could not be recognized. Please try again!";
    const BotResponse = `<img class="botAvatar" src="https://st3.depositphotos.com/30456762/37578/v/600/depositphotos_375780486-stock-illustration-chat-bot-robot-avatar-in.jpg"/><p class="botMsg">${is_verified_message}</p><div class="clearfix"></div>`;

    $(BotResponse).appendTo(".chats").hide().fadeIn(2000); 
}

function speechRecognize(text){
    if(text == "Speech could not be recognized"){
        speechNotRecognized();
    }
    else {
        const userInputField = document.querySelector('.usrInput');
        $(".usrInput").hide().val(text).fadeIn(500);
        userInputField.focus();
    }
}
/**
 * sends the user message to the rasa server,
 * @param {String} message user message
 */
function send(message) {
    $.ajax({
        url: rasa_server_url,
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify({ message, sender: sender_id }),
        success(botResponse, status) {
            console.log("Response from Rasa: ", botResponse, "\nStatus: ", status);
            response_status = status
            console.log("response_status", response_status);

            if (message.toLowerCase() === "/restart") {
                $("#userInput").prop("disabled", false);

                return;
            }
            setBotResponse(botResponse);
        },
        error(xhr, textStatus) {
            if (message.toLowerCase() === "/restart") {
                $("#userInput").prop("disabled", false);

            }

            setBotResponse("");
            console.log("Error from bot end: ", textStatus);
        },
    });
}

function botResponse(message) {
    $.ajax({
        url: rasa_server_url,
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify({ message, sender: sender_id }),
        success(botResponse, status) {
            console.log("Response from Rasa: ", botResponse, "\nStatus: ", status);
            response_status = status
            console.log("response_status", response_status);

            if (message.toLowerCase() === "/restart") {
                $("#userInput").prop("disabled", false);

                return;
            }
            return botResponse;
        },
        error(xhr, textStatus) {
            if (message.toLowerCase() === "/restart") {
                $("#userInput").prop("disabled", false);

            }

            setBotResponse("");
            console.log("Error from bot end: ", textStatus);
        },
    });
}


function actionTrigger() {
    $.ajax({
        url: `http://localhost:5005/conversations/${sender_id}/execute`,
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify({
            name: action_name,
            policy: "MappingPolicy",
            confidence: "0.98",
        }),
        success(botResponse, status) {

            if (Object.hasOwnProperty.call(botResponse, "messages")) {
                setBotResponse(botResponse.messages);
            }
            $("#userInput").prop("disabled", false);
        },
        error(xhr, textStatus) {
            setBotResponse("");
            console.log("Error from bot end: ", textStatus);
            $("#userInput").prop("disabled", false);
        },
    });
}


var response_status= 0;
function customActionTrigger() {
    $.ajax({
        url: "http://localhost:5055/webhook/",
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify({
            next_action: action_name,
            tracker: {
                sender_id,
            },
        }),
        success(botResponse, status) {
            response_status = status;
            console.log(status);

            if (Object.hasOwnProperty.call(botResponse, "responses")) {
                setBotResponse(botResponse.responses);
            }
            $("#userInput").prop("disabled", false);
        },
        error(xhr, textStatus) {
            setBotResponse("");
            console.log("Error from bot end: ", textStatus);
            $("#userInput").prop("disabled", false);
        },
    });
}



function restartConversation() {
    $("#userInput").prop("disabled", true);
    $(".collapsible").remove();

    if (typeof chatChart !== "undefined") {
        chatChart.destroy();
    }

    $(".chart-container").remove();
    if (typeof modalChart !== "undefined") {
        modalChart.destroy();
    }
    $(".chats").html("");
    $(".usrInput").val("");
    send("/restart");
}
$("#restart").click(() => {
    restartConversation();
});


function displayText(inputText){
    const InitMessage = inputText;
    const BotResponse = `<img class="botAvatar" src="https://st3.depositphotos.com/30456762/37578/v/600/depositphotos_375780486-stock-illustration-chat-bot-robot-avatar-in.jpg"/><p class="botMsg">${InitMessage}</p><div class="clearfix"></div>`;
    $(BotResponse).appendTo(".chats").hide().fadeIn(1000);
}
$(document).ready(() => { 

    var userNID = ""; 
    var user_name = "";
    console.log(sender_id);
    var validatedNIDConfirmation = false;
    const InitMessage = "Please first enter your NID: ";
    console.log(`sender id (chat.js):`, sender_id);
    console.log(`ChatbotUserSocketID_socket (inside "chat.js" file):`, ChatbotUserSocketID_socket);
    displayText(InitMessage);
    setTimeout(() => {
        const fetchNID = async () => {
            try {
                const response = await fetch(`http://127.0.0.1:8080/home/api/user-chatbot/socket/${sender_id}/`);
                const data = await response.json(); 
                userNID = "123456"; 
                user_name = data.first_name + ' ' + data.last_name;
                console.log(`Username:`, user_name);
                console.log(`After successfully fetching user NID ('chat.js' file):`, userNID);
                $(".usrInput").removeAttr("disabled"); 
            } catch (error) { 
                console.log(error); 
            } 
        };
        fetchNID()
    }, 1000); 


    $(".usrInput").attr("disabled", true); 

    const validateNID = (text) => { 
        if (text == userNID) { 
            return true; 
        } else { 
            const InitMessage = "Please enter correct NID: ";
            $("textarea#userInput").val('');
            displayText(InitMessage);
            return false; 
        } 
    }; 
    $(".usrInput").on("keypress", (e) => { 

        const keyCode = e.keyCode || e.which; 
        var text = $("textarea#userInput").val(); 
        if (keyCode === 13) 
        {
            console.log(text);
            if (text === "" || $.trim(text) === "") { 
                e.preventDefault(); 
                return false; 
            } 

            if (validatedNIDConfirmation == false){
                if (!validateNID(text)) {
                    validatedNIDConfirmation = false;
                    return false; 
                }
                else{
                    validatedNIDConfirmation = true;
                    const user_navbar = `<p>User ID: ${userNID} <span id="user-id"></span></p> <p>User Name: ${user_name} <span id="user-name"></span></p>`;
                    $(user_navbar).appendTo(".user-details").hide().fadeIn(1000);
                    $(".chatbox-navbar").toggle();
                   
                    setUserResponse(text);
                    setNIDverificationSuccessful();
                    // send(text); 
                    e.preventDefault();
                    return false;
                }
            }
             
            else{
                validatedNIDConfirmation = true;
                $(".collapsible").remove(); 
                $(".dropDownMsg").remove(); 
                if (typeof chatChart !== "undefined") { 
                    chatChart.destroy(); 
                } 
                $(".chart-container").remove(); 
                if (typeof modalChart !== "undefined") {
                    modalChart.destroy(); 
                } 
                $("#paginated_cards").remove(); 
                $(".suggestions").remove(); 
                $(".quickReplies").remove(); 
                $(".usrInput").blur(); 
                setUserResponse(text);
                const resp = botResponse(text);
                sendDataToClickHouse(text, resp);
                send(text); 
                e.preventDefault();
                return false; 

            }
        } 
        return true; 
    }); 
}); 

$("#sendButton").on("click", (e) => {
    const text = $(".usrInput").val();
    if (text === "" || $.trim(text) === "") {
        e.preventDefault();
        return false;
    }
    if (typeof chatChart !== "undefined") {
        chatChart.destroy();
    }

    $(".chart-container").remove();
    if (typeof modalChart !== "undefined") {
        modalChart.destroy();
    }

    $(".suggestions").remove();
    $("#paginated_cards").remove();
    $(".quickReplies").remove();
    $(".usrInput").blur();
    $(".dropDownMsg").remove();
    setUserResponse(text);
    const resp = botResponse(text);
    sendDataToClickHouse(text, resp);
    send(text);
    e.preventDefault();
    return false;
});
